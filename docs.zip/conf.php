<?php

//environnement production
$GLOBALS["envProd"] = false;

//database connection
$GLOBALS["db"] = [
    "host"      => 'localhost',
    "user"      => 'root',
    "password"  => '',
    "database"  => 'OCR-Projet5-DB'
];

//pour récupérer l'URL
$GLOBALS["uri_Start"] = 3;
$GLOBALS["path"] = "/OCR-Projet5/Code-Projet5";

